import React, { useEffect, useState } from 'react';
import { API } from './API';

const Alerts = () => {
  const [alerts, setAlerts] = useState([]);

  const fetchAlerts = async () => {
    const response = await fetch(`${API}/api/notifications/`);
    const data = await response.json();
    setAlerts(data);
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  return (
    <div className="alerts">
      <h2>Alertas</h2>
      <ul>
        {alerts.map((alert, index) => (
          <li key={index}>{alert.message}</li>
        ))}
      </ul>
    </div>
  );
};

export default Alerts;
