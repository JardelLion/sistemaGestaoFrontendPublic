import React, { useEffect, useState } from 'react';
import { API } from './API';

const SalesStats = () => {
  const [salesData, setSalesData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Função para buscar dados da API
  const fetchData = async (url) => {
    const token = localStorage.getItem('access_token'); // Obtém o token de acesso do localStorage
    try {
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          // Token expirado, tentar renovar o token
          await renewToken();
          // Tentar novamente após renovar o token
          return fetchData(url);
        }
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      setSalesData(data);
    } catch (error) {
      console.error(`Error fetching data from ${url}:`, error);
      setError(`Não foi possível carregar os dados de ${url.split('/')[2]}.`);
    } finally {
      setLoading(false);
    }
  };

  // Função para renovar o token
  const renewToken = async () => {
    try {
      const refreshToken = localStorage.getItem('refresh_token'); // Supondo que você armazena o refresh token no localStorage
      const response = await fetch(`${API}/api/token/refresh/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refresh: refreshToken }),
      });

      if (!response.ok) {
        throw new Error('Unable to refresh token');
      }

      const { access } = await response.json();
      localStorage.setItem('access_token', access); // Atualiza o token no localStorage
    } catch (error) {
      console.error('Error renewing token:', error);
      setError('Erro ao renovar o token. Por favor, faça login novamente.');
      // Redirecionar para a página de login, se necessário
      // navigate('/');
    }
  };

  useEffect(() => {
    const fetchSalesData = async () => {
      setLoading(true);
      await fetchData(`${API}/api/static-value`);
    };

    fetchSalesData();
  }, []); // O array de dependências está vazio para buscar dados apenas na montagem do componente

  if (loading) {
    return <p>Loading sales data...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  if (!salesData || salesData.length === 0) {
    return <p>No sales data available.</p>;
  }

  // Exemplo de como processar os dados
  const totalSales = salesData.total_sales_value;
  
  return (
    <div className="sales-stats">
      <h2>Estatísticas de Vendas</h2>
      <p>Total de Vendas: {totalSales}</p>
      {/* Adicione mais estatísticas conforme necessário */}
    </div>
  );
};

export default SalesStats;
