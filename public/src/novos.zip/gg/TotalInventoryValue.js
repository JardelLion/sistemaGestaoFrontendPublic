import React, { useEffect, useState } from 'react';
import { API } from './API';

const TotalInventoryValue = () => {
  const [totalValue, setTotalValue] = useState(0);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  // Função para renovar o token
  const renewToken = async () => {
    try {
      const refreshToken = localStorage.getItem('refresh_token'); // Supondo que você armazena o refresh token no localStorage
      const response = await fetch(`${API}/api/token/refresh/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refresh: refreshToken }),
      });

      if (!response.ok) {
        throw new Error('Unable to refresh token');
      }

      const { access } = await response.json();
      localStorage.setItem('access_token', access); // Atualiza o token no localStorage
    } catch (error) {
      console.error('Error renewing token:', error);
      setError('Erro ao renovar o token. Por favor, faça login novamente.');
      // Redirecionar para a página de login, se necessário
      // navigate('/');
    }
  };

  // Função para buscar o valor total do estoque
  const fetchTotalInventoryValue = async () => {
    const token = localStorage.getItem('access_token'); // Obtém o token de acesso do localStorage
    try {
      const response = await fetch(`${API}/api/total-product-value/`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          // Token expirado, tentar renovar o token
          await renewToken();
          // Tentar novamente após renovar o token
          return fetchTotalInventoryValue();
        }
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      setTotalValue(data.total_stock_value);
    } catch (error) {
      console.error('Error fetching total inventory value:', error);
      setError('Não foi possível carregar o valor total do estoque.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTotalInventoryValue();
  }, []);

  return (
    <div className="total-inventory-value">
      <h2>Valor Total da Mercadoria</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error-message">{error}</p>}
      <p>Total: ${totalValue}</p>
    </div>
  );
};

export default TotalInventoryValue;
