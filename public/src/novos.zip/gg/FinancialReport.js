import React, { useEffect, useState } from 'react';
import { API } from './API';

const FinancialReport = () => {
  const [report, setReport] = useState({ totalSales: 0, totalExpenses: 0, profit: 0 });

  const fetchFinancialReport = async () => {
    const response = await fetch(`${API}/api/static-value/`);
    const data = await response.json();
    setReport(data);
  };

  useEffect(() => {
    fetchFinancialReport();
  }, []);

  return (
    <div className="financial-report">
      <h2>Relatório Financeiro</h2>
      <p>Total de Vendas: {report.total_sales_value}</p>
      <p>Total de Despesas: {report.total_spend}</p>
      <p>Lucro: {report.profit}</p>
    </div>
  );
};

export default FinancialReport;
