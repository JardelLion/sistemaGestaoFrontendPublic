import React, { useEffect, useState } from 'react';
import { API } from './API';

const ProfitMargin = () => {
  const [margin, setMargin] = useState(0);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  // Função para renovar o token
  const renewToken = async () => {
    try {
      const refreshToken = localStorage.getItem('refresh_token'); // Supondo que você armazena o refresh token no localStorage
      const response = await fetch(`${API}/api/token/refresh/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refresh: refreshToken }),
      });

      if (!response.ok) {
        throw new Error('Unable to refresh token');
      }

      const { access } = await response.json();
      localStorage.setItem('access_token', access); // Atualiza o token no localStorage
    } catch (error) {
      console.error('Error renewing token:', error);
      setError('Erro ao renovar o token. Por favor, faça login novamente.');
      // Redirecionar para a página de login, se necessário
      // navigate('/');
    }
  };

  // Função para buscar a margem de lucro
  const fetchProfitMargin = async () => {
    const token = localStorage.getItem('access_token'); // Obtém o token de acesso do localStorage
    try {
      const response = await fetch(`${API}/api/static-value/`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          // Token expirado, tentar renovar o token
          await renewToken();
          // Tentar novamente após renovar o token
          return fetchProfitMargin();
        }
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      setMargin(data.margin);
    } catch (error) {
      console.error('Error fetching profit margin:', error);
      setError('Não foi possível carregar a margem de venda.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfitMargin();
  }, []);

  return (
    <div className="profit-margin">
      <h2>Margem de Venda</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error-message">{error}</p>}
      <p>Margem: {margin.toFixed(2)}%</p>
    </div>
  );
};

export default ProfitMargin;
